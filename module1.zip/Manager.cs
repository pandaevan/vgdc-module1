using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Manager : MonoBehaviour
{
 public Text ClicksTotalText;
[SerializeField] GameObject upgrade1;
public int ACPS;
public int MCPSU;
public int FishMultiplyer;
public float cost;
 public float mult;
 float TotalClicks;
 bool HasUpgrade1;
 bool HasUpgrade2;
 public void AddClicks()
 {
TotalClicks++;
ClicksTotalText.text = TotalClicks.ToString("0");
 }
 public void autoclickupgrade()
 {
    if(!HasUpgrade1 && TotalClicks >= MCPSU)
    {
        TotalClicks -= MCPSU;
        HasUpgrade1 = true;
    }
 }
 public void upgrademult()
 {
        if(!HasUpgrade2 && TotalClicks >= cost )
    {
        TotalClicks -= cost;
        HasUpgrade2 = true;
        
    }
 }
     void Update() 
    {
        if(HasUpgrade1)
        {
            TotalClicks += ACPS * FishMultiplyer * Time.deltaTime;
            ClicksTotalText.text = TotalClicks.ToString("0");
            Destroy(upgrade1);
        }
        if(HasUpgrade2)
        {
            cost += 10 * mult * Time.deltaTime;
            mult += cost;
            FishMultiplyer += 1;
            HasUpgrade2 = false;
        }
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
            Debug.Log("quit");
        }
    }
}
